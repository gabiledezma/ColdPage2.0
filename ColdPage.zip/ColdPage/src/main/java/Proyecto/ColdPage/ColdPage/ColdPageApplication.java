package Proyecto.ColdPage.ColdPage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ColdPageApplication {

	public static void main(String[] args) {
		SpringApplication.run(ColdPageApplication.class, args);
	}

}
