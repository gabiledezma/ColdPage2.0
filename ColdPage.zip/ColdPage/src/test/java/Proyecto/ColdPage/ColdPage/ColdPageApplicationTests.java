package Proyecto.ColdPage.ColdPage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ColdPageApplicationTests {

	@Test
	void contextLoads() {
	}

}
